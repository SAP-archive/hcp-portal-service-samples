window.tinymce.PluginManager.add("myplugin", function(editor) {
	// Add your code here
});