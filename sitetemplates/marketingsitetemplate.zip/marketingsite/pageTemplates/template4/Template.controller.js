sap.ui.controller("cpv2.templates.template4.Template", {

	onInit: function() {

	}
});